import { StyleSheet, Dimensions, Platform } from 'react-native';
import Colors from '../../Styles/Colors';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';

const widthScreen = Dimensions.get('window').width;
const heightScreen = Dimensions.get('window').height;

const styles = StyleSheet.create({
  modalCont: {
    height: hp('28%'),
    width: widthScreen / 1.2,
    alignSelf: 'center',
    backgroundColor: Colors.White,
    borderRadius: 15,
    overflow: 'hidden',
    // marginTop: WP('5'),
  },
  modalContainer: {
    marginTop: hp(2),
    marginBottom: hp(2),
    width: '90%',
    alignSelf: 'center'
  },
  closeContainer: {
    alignSelf: 'flex-end'
  },
  crossImage: {
    width: hp(2.8),
    height: hp(2.8)
  },
  userImage: {
    marginTop: hp(2),
    width: hp(8),
    height: hp(8),
    alignSelf: 'center'
  },
  successText: {
    marginTop: hp(2),
    width: "85%",
    alignSelf: 'center',
    fontSize: hp(2.2),
    fontWeight: '500',
    color: Colors.lightBrown
  }
});
export default styles;