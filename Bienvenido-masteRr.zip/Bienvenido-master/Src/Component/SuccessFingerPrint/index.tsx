import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
} from 'react-native';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Styles from './Styles';
import Modal from 'react-native-modal';
import Images from '../../Styles/Images';
import Colors from '../../Styles/Colors';

const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

type IProps = {
  navigation: any;
  close: any;
  open: any;
};
type IState = {

};

class SuccessFingerPrint extends Component<IProps, IState> {
  constructor(props: any) {
    super(props);
    this.state = {

    };
  }


  render() {

    return (
      <Modal animationInTiming={300}
        animationOutTiming={200}
        animationIn="bounceInRight"
        animationOut="bounceInRight"
        backdropOpacity={0.7}
        avoidKeyboard={true}
        backdropColor={"rgba(196,196,196,0.9)"}
        // transparent={true}
        isVisible={this.props.open}
        onBackdropPress={() => { this.props.close() }}
        style={{ flex: 1, justifyContent: "center" }}>
        <View style={Styles.modalCont}>
          <View style={Styles.modalContainer}>
            <TouchableOpacity onPress={() => { this.props.close() }}
              style={Styles.closeContainer}>
              <Image source={Images.cross} style={Styles.crossImage} />
            </TouchableOpacity>
            <Image source={Images.userIcon} style={Styles.userImage} />
            <Text style={Styles.successText}>{"Para activar la huella primero ingresa usuario y contraseña."}</Text>
          </View>
        </View>
      </Modal>
    );
  }
}

export default SuccessFingerPrint