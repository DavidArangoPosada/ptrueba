import { StyleSheet, Dimensions, Platform } from 'react-native';
import Colors from '../../../Styles/Colors';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';

const widthScreen = Dimensions.get('window').width;
const heightScreen = Dimensions.get('window').height;

const styles = StyleSheet.create({
  fullContainer: {
    flex: 1,
    backgroundColor: Colors.White
  },
  safeAreaContainer: {
    flex: 1,
    backgroundColor: Colors.White
  },
  headingBackground: {
    width: widthScreen,
    height: heightScreen
  },
  logoStyle: {
    width: hp(22),
    height: hp(17),
    marginTop: hp(5.5)
  },
  innerHeader: {
    width: widthScreen / 1.2,
    alignSelf: 'center',
    justifyContent: 'flex-end',
    flex: 0.9
  },
  loginText: {
    fontSize: hp(4),
    fontWeight: '700',
    color: Colors.White,
  },
  headerContent: {
    flex: 1
  },
  bottomContent: {
    flex: 0.3,
    justifyContent: 'flex-end',
    alignItems: 'center'
  },
  bottomContent1: {
    flex: 0.7,
    justifyContent: 'center',
    alignItems: 'center'
  },
  bottomContainer: {
    width: widthScreen / 1.12,
    alignSelf: 'center',
    marginTop: hp(3)
  },
  bottomContainer1: {
    width: widthScreen / 1.12,
    alignSelf: 'center',
    // marginTop: hp(3),
    marginBottom: hp(1)
  },
  emailWrapper: {
    flexDirection: 'row',
    borderRadius: 6,
    backgroundColor: Colors.lightGrey,
    height: hp(6),
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    width: widthScreen / 1.12,
    marginTop: hp(3)
  },
  emailInput: {
    marginLeft: hp(1.5),
    flex: 1,
    fontSize: hp(2),
    color: Colors.White,
    fontWeight: '500'
  },
  orderCheckContainer: {
    width: widthScreen / 1.2,
    marginTop: hp(4),
    flexDirection: 'row',
    alignSelf: 'center',
  },
  cartProductName: {
    fontSize: hp(1.8),
    fontWeight: '500',
    color: Colors.Black,
  },
  loginButtonContainer: {
    width: widthScreen / 1.2,
    marginTop: hp(4),
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between'
  },
  checkOutButton: {
    width: hp(20),
    alignSelf: 'center',
    height: hp(5),
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.green,
    marginTop: hp(3.5)
  },
  checkOutText: {
    fontSize: hp(2),
    color: Colors.White,
    fontWeight: '700',
  },
  forgotText: {
    fontSize: hp(1.7),
    color: Colors.lightBlack,
    fontWeight: '400',
    marginTop: hp(1.5),
    width: widthScreen / 1.12,
    alignSelf: 'center',
    textDecorationLine: 'underline'
  },
  noAccountText: {
    fontSize: hp(1.85),
    color: Colors.mediumGrey,
    fontWeight: '500',
    marginTop: hp(2),
    textAlign: 'center',
    textDecorationLine: 'underline'
  },
  inputImage: {
    width: hp(2.7),
    height: hp(2),
    marginLeft: hp(1),
    // marginTop: -7
  },
  inputImage1: {
    width: hp(2.7),
    height: hp(2.7),
    marginLeft: hp(1),
    marginTop: -5
  },
  logoImage: {
    width: widthScreen / 1.12,
    alignSelf: 'center',
    height: hp(14.5)
  },
  logoText: {
    fontSize: hp(2.5),
    fontWeight: '600',
    color: Colors.green,
    marginBottom: hp(4),
    textAlign: "center"
  },
  fingerStyle: {
    width: hp(8),
    height: hp(8),
    alignSelf: 'center',
    marginTop: hp(2)
  },
  fingerText: {
    fontSize: hp(1.5),
    color: Colors.mediumGrey,
    fontWeight: '400',
    marginTop: hp(1),
    textAlign: 'center',
    width: hp(10),
    alignSelf: 'center'
  }
});
export default styles;