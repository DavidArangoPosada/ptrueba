import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SafeAreaView from 'react-native-safe-area-view';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Styles from './Styles';
import Images from '../../../Styles/Images';
import Colors from '../../../Styles/Colors';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import SuccessFingerPrint from '../../../Component/SuccessFingerPrint';
import ReactNativeBiometrics from 'react-native-biometrics'

const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

type IProps = {
  navigation: any;
};
type IState = {
  password: any,
  email: any,
  passwordSeen: boolean,
  openModel: boolean
};

class Login extends Component<IProps, IState> {
  constructor(props: any) {
    super(props);
    this.state = {
      email: '',
      password: '',
      passwordSeen: false,
      openModel: false
    };
  }

  clickFinger = () => {
    const reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    const { email, password } = this.state
    if (email.length == 0 || reg.test(email) === false) {
      this.setState({ openModel: !this.state.openModel })
    }
    else if (
      email.length == 0 ||
      password.trim().length < 8
    ) {
      this.setState({ openModel: !this.state.openModel })
    }
    else {
      // ReactNativeBiometrics.isSensorAvailable()
      //   .then((resultObject) => {
      //     const { available, biometryType } = resultObject

      //     if (available && biometryType === ReactNativeBiometrics.TouchID) {
      //       console.log('TouchID is supported')
      //     } else if (available && biometryType === ReactNativeBiometrics.FaceID) {
      //       console.log('FaceID is supported')
      //     } else if (available && biometryType === ReactNativeBiometrics.Biometrics) {
      //       console.log('Biometrics is supported')
      //     } else {
      //       console.log('Biometrics not supported')
      //     }
      //   })

      // this.closeModel()
    }
  }
  closeModel = () => {
    setTimeout(() => {
      this.setState({ openModel: false })
      this.props.navigation.navigate('Onboarding')
    }, 5000);
  }

  render() {
    const { password, email, passwordSeen, openModel } = this.state

    return (
      <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
        contentContainerStyle={Styles.fullContainer}>
        <SafeAreaProvider>
          <SafeAreaView style={Styles.safeAreaContainer} forceInset={{ top: 'never' }}>
            <StatusBar barStyle="light-content" />
            {/* <ScrollView showsVerticalScrollIndicator={false}> */}
            <ImageBackground source={Images.main} style={Styles.headingBackground} >
              <View style={Styles.headerContent}>
                <View style={Styles.bottomContent}>
                  <Text style={Styles.logoText}>{"Bienvenido"}</Text>
                  <Image source={Images.logo} style={Styles.logoImage} />
                </View>
                <View style={Styles.bottomContent1}>
                  <View style={Styles.bottomContainer}>

                    {/* Email */}
                    <View style={Styles.emailWrapper}>
                      <TouchableOpacity>
                        <Image source={Images.email} style={Styles.inputImage} />
                      </TouchableOpacity>
                      <TextInput
                        style={Styles.emailInput}
                        value={email}
                        placeholder={"Usuario"}
                        placeholderTextColor={Colors.White}
                        autoCapitalize='none'
                        onChangeText={(value) => {
                          this.setState({
                            email: value,
                          })
                        }}
                      />
                    </View>
                    {/* Password */}
                    <View style={Styles.emailWrapper}>
                      <TouchableOpacity>
                        <Image source={Images.lock} style={Styles.inputImage1} />
                      </TouchableOpacity>
                      <TextInput
                        style={Styles.emailInput}
                        value={password}
                        placeholder={"Contraseña "}
                        secureTextEntry={passwordSeen == false ? true : false}
                        placeholderTextColor={Colors.White}
                        autoCapitalize='none'
                        onChangeText={(value) => {
                          this.setState({
                            password: value,
                          })
                        }}
                      />

                    </View>

                    <Text style={Styles.forgotText}>{"Olvidé mi contraseña"}</Text>

                    <TouchableOpacity onPress={() => {
                      this.props.navigation.navigate('Onboarding')
                    }}
                      style={Styles.checkOutButton}>
                      <Text style={Styles.checkOutText}>{"INGRESAR"}</Text>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={this.clickFinger}>
                      <Image source={Images.fingerPrint} style={Styles.fingerStyle} />
                    </TouchableOpacity>
                    <Text style={Styles.fingerText}>{"Ingresar con huella"}</Text>

                    <Text style={Styles.noAccountText}>{"Obtener mi usurario"}</Text>
                  </View>


                </View>
                {
                  openModel ?
                    <SuccessFingerPrint open={openModel}
                      navigation={this.props.navigation}
                      close={this.clickFinger} />
                    : null
                }
              </View>
            </ImageBackground>
          </SafeAreaView>
        </SafeAreaProvider>
      </KeyboardAwareScrollView>
    );
  }
}

export default Login