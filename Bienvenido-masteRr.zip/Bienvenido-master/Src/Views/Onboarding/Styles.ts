import { StyleSheet, Dimensions } from 'react-native';
import Metrics from '../../Styles/Metrices';
import Colors from '../../Styles/Colors';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';


const widthScreen = Dimensions.get('window').width;
const styles = StyleSheet.create({
  mainConatiner: {
    flex: 1,
    width: Metrics.screenWidth,
    height: Metrics.screenHeight,
    backgroundColor: 'white',
  },
  mainContainer: {
    flex: 0.85,
  },
  headContainer: {
    width: widthScreen / 1.12,
    alignSelf: 'center',
    marginTop: hp(6),
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  bottomContainer: {
    flex: 0.15,
    // justifyContent: 'center',
    alignItems: 'center',
  },
  titleText: {
    fontSize: hp(3.5),
    color: Colors.lightBrown,
    fontWeight: '600',
    alignSelf: 'center',
    marginTop: hp(3)
  },
  desText: {
    fontSize: hp(2.5),
    color: Colors.lightBrown,
    fontWeight: '400',
    marginTop: hp(2),
    width: widthScreen / 1.45,
    alignSelf: 'center',
  },
  backIcon: {
    width: hp(3.5),
    height: hp(3),
    // marginTop: hp(4)
  },
  logoStyle: {
    width: hp(12),
    height: hp(12)
  },
  headStyle: {
    fontSize: hp(2.5),
    fontWeight: '400',
    color: Colors.lightBrown,
    textDecorationLine: 'underline',
    marginTop: hp(0.4)
  },
  donateButton: {
    width: hp(20),
    alignSelf: 'center',
    height: hp(5),
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.green,
    marginTop: hp(1.5),
    marginBottom: hp(3)
  },
  donateText: {
    fontSize: hp(2),
    color: Colors.White,
    fontWeight: '700',
  },
  mainImageContainer: {
    marginTop: hp(8),
    width: widthScreen / 1.12,
    alignSelf: 'center',
  },
  mainImage: {
    width: 235.58,
    alignSelf: 'center',
    height: 207.98
  }
});
export default styles;
