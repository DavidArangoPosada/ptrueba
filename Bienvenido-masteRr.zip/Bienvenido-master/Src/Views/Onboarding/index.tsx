import React, { Component } from 'react';
import { View, Image, Text, TouchableOpacity, Dimensions, SafeAreaView } from 'react-native';
import AppIntroSlider from 'react-native-app-intro-slider';
import Images from '../../Styles/Images';
import Colors from '../../Styles/Colors';
import * as Constants from '../../Constants';
import Styles from './Styles';

const widthScreen = Dimensions.get('window').width;

type IProps = {
  navigation: any;
};
type IState = {
  next: any
};

const slides = [
  {
    key: 1,
    title: Constants.ONBOARD_TITLE,
    description: Constants.ONBOARD_DES,
    image: Images.onboard,
    backgroundColor: 'white',
  },
  {
    key: 2,
    title: Constants.ONBOARD_TITLE,
    description: Constants.ONBOARD_DES,
    image: Images.onboard,
    backgroundColor: 'white',
  },
  {
    key: 3,
    title: Constants.ONBOARD_TITLE,
    description: Constants.ONBOARD_DES,
    image: Images.onboard,
    backgroundColor: 'white',
  },
];

export default class Onboarding extends Component<IProps, IState> {
  slider: any;
  constructor(props: any) {
    super(props);
    this.slider = React.createRef();
    this.state = {
      next: 0,
    };
  }

  _renderItem = ({ item }: any) => {
    return (
      <View style={Styles.mainConatiner}>
        <View style={Styles.mainContainer}>
          <View style={Styles.headContainer}>
            <TouchableOpacity onPress={() => { this.props.navigation.goBack() }}>
              <Image source={Images.backArrow} style={Styles.backIcon} />
            </TouchableOpacity>
            <Image source={Images.singleLogo} style={Styles.logoStyle} />
            <Text style={Styles.headStyle}>{"Omitir"}</Text>
          </View>
          <Text style={Styles.titleText}>{item.title}</Text>
          <Text style={Styles.desText}>{item.description}</Text>
          <TouchableOpacity style={Styles.mainImageContainer}>
            <Image source={item.image} style={Styles.mainImage} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  goNext = () => {
    this.setState({ next: this.state.next + 1 });
    this.slider.goToSlide(this.state.next + 1, true);
  };
  RenderNextButton = () => {
    return (
      <>
        <TouchableOpacity
          onPress={this.goNext}
          style={Styles.donateButton}>

          <Text style={Styles.donateText}>{"Siguiente"}</Text>
        </TouchableOpacity>
      </>
    );
  };
  changeSlide = (e: any) => {
    this.setState({ next: e });
  };
  render() {
    return (
      <AppIntroSlider
        ref={(ref: any) => (this.slider = ref)}
        onSlideChange={(e: any) => this.changeSlide(e)}
        renderItem={this._renderItem}
        renderNextButton={this.RenderNextButton}
        renderDoneButton={this.RenderNextButton}

        data={slides}
        // onDone={this._onDone}
        bottomButton={true}
        dotStyle={{
          backgroundColor: '#E5E5E5', marginBottom: '10%',
          width: 25, borderRadius: 25, height: 25
        }}
        activeDotStyle={{
          backgroundColor: "#EE7417", marginBottom: '10%',
          width: 25, borderRadius: 25, height: 25
        }}
      />
    );
  }
}
