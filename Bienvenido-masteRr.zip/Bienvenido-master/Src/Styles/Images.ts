const images = {

  //Login Assets
  logo: require('../Assets/logo.png'),
  main: require('../Assets/main.png'),
  email: require('../Assets/email.png'),
  lock: require('../Assets/lock.png'),
  fingerPrint: require('../Assets/fingerPrint.png'),
  userIcon: require('../Assets/userIcon.png'),
  onboard: require('../Assets/onboard.png'),
  cross: require('../Assets/cross.png'),
  singleLogo: require('../Assets/singleLogo.png'),
  backArrow: require('../Assets/backArrow.png'),
};
export default images;