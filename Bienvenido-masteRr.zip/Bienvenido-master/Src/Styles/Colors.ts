const colors = {
  Black: "#000000",
  White: "#FFFFFF",
  lightGrey: "#C4C4C4",
  green: "#00805D",
  mediumGrey: '#4A4747',
  lightBlack: "#4F4E4E",
  lightBrown: "#706262"
};

export default colors;
