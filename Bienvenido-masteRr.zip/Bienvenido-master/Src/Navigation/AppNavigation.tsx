
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator, StackNavigationProp } from '@react-navigation/stack';
import { enableScreens } from 'react-native-screens';

import Login from '../Views/Authentication/Login';
import Onboarding from '../Views/Onboarding';

// import DrawerContent from '../Screens/MainScreens/Drawer';
type RootStackParamList = {
  Login: undefined,
  Onboarding: undefined
};


enableScreens();

const Stack = createStackNavigator<RootStackParamList>();
// const navigationRef = React.createRef();

// export function navigate(name: any, params: any) {
//   navigationRef.current?.navigate(name, params);
// }
export const setNavigator = (nav: any) => {
  const navigator = nav;
};

export default function RootNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Login'
        screenOptions={{
          headerShown: false,
        }}>
        <Stack.Screen name='Login' component={Login} options={{ headerShown: false }} />
        <Stack.Screen name='Onboarding' component={Onboarding} options={{ headerShown: false }} />

        {/*  */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}





