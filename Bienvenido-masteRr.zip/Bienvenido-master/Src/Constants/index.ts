
export const ONBOARD_TITLE = "Activar huella"
export const ONBOARD_DES = "Ingresa de una manera fácil y segura a nuestra aplicación."