import React from 'react';
import Root from './Src/setup';

const App = () => {
  return (
    <>
      <Root />
    </>
  );
};
export default App;