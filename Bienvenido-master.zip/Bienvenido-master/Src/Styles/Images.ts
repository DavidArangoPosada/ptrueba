const images = {

  //Login Assets
  logo: require('../Assets/logo.png'),
  main: require('../Assets/main.png'),
  email: require('../Assets/email.png'),
  lock: require('../Assets/lock.png'),

  

};
export default images;