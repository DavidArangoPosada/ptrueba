import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
} from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SafeAreaView from 'react-native-safe-area-view';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Styles from './Styles';
import Images from '../../../Styles/Images';
import Colors from '../../../Styles/Colors';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';

const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

type IProps = {
  navigation: any;
};
type IState = {
  password: any,
  email: any,
  passwordSeen: boolean,
};

class Login extends Component<IProps, IState> {
  constructor(props: any) {
    super(props);
    this.state = {
      email: '',
      password: '',
      passwordSeen: false,
    };
  }



  render() {
    const { password, email, passwordSeen } = this.state

    return (
      <>
        <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
          contentContainerStyle={Styles.fullContainer}>
          <SafeAreaProvider>
            <SafeAreaView style={Styles.safeAreaContainer} forceInset={{ top: 'never' }}>
              <StatusBar barStyle="light-content" />
              {/* <ScrollView showsVerticalScrollIndicator={false}> */}
              <ImageBackground source={Images.main} style={Styles.headingBackground} >
                <View style={Styles.headerContent}>
                  <View style={Styles.bottomContent}>
                    <Text style={Styles.logoText}>{"Bienvenido"}</Text>
                    <Image source={Images.logo} style={Styles.logoImage} />
                  </View>
                  <View style={Styles.bottomContent1}>
                    <View style={Styles.bottomContainer}>

                      {/* Email */}
                      <View style={Styles.emailWrapper}>
                        <TouchableOpacity>
                          <Image source={Images.email} style={Styles.inputImage} />
                        </TouchableOpacity>
                        <TextInput
                          style={Styles.emailInput}
                          value={email}
                          placeholder={"Usuario"}
                          placeholderTextColor={Colors.White}
                          autoCapitalize='none'
                          onChangeText={(value) => {
                            this.setState({
                              email: value,
                            })
                          }}
                        />
                      </View>
                      {/* Password */}
                      <View style={Styles.emailWrapper}>
                        <TouchableOpacity>
                          <Image source={Images.lock} style={Styles.inputImage1} />
                        </TouchableOpacity>
                        <TextInput
                          style={Styles.emailInput}
                          value={password}
                          placeholder={"Contraseña "}
                          secureTextEntry={passwordSeen == false ? true : false}
                          placeholderTextColor={Colors.White}
                          autoCapitalize='none'
                          onChangeText={(value) => {
                            this.setState({
                              password: value,
                            })
                          }}
                        />

                      </View>

                      <Text style={Styles.forgotText}>{"Olvidé mi contraseña"}</Text>

                      <TouchableOpacity
                        style={Styles.checkOutButton}>
                        <Text style={Styles.checkOutText}>{"INGRESAR"}</Text>
                      </TouchableOpacity>

                      <Text style={Styles.noAccountText}>{"Obtener mi usurario"}</Text>
                    </View>


                  </View>

                </View>
              </ImageBackground>
            </SafeAreaView>
          </SafeAreaProvider>
        </KeyboardAwareScrollView>
      </>
    );
  }
}

export default Login